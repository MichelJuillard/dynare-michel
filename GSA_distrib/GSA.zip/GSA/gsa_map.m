function [S, S_log, gsa_, gsa_log, f1] = gsa_map(x, ya, pshape, pd, gsa_flag, MhDirectoryName, fname)
%[S, S_pca, gsa_, gsa_pca, v0, d0] = gsa_map(x, ya, gsa_flag, MhDirectoryName, fname)
% 1.28 for 80%
% 1.65 for 90%
% 1.96 for 95%
%
% Part of the Sensitivity Analysis Toolbox for DYNARE
%
% Written by Marco Ratto, 2006
% Joint Research Centre, The European Commission,
% (http://eemc.jrc.ec.europa.eu/),
% marco.ratto@jrc.it 
%
% Disclaimer: This software is not subject to copyright protection and is in the public domain. 
% It is an experimental system. The Joint Research Centre of European Commission 
% assumes no responsibility whatsoever for its use by other parties
% and makes no guarantees, expressed or implied, about its quality, reliability, or any other
% characteristic. We would appreciate acknowledgement if the software is used.
% Reference:
% M. Ratto, Global Sensitivity Analysis for Macroeconomic models, MIMEO, 2006.
%

global M_

j0=size(ya,2);
S=zeros(j0,size(x,2));
S_log=S;
for j=1:j0,
  y0=ya(:,j);
  isig=1;
  y1=y0;
  if skewness(y0)<0,
    isig=-1;
    y1=-y0;
  end
  n=hist(y1,10);
  if n(1)>20*n(end),
    f=inline('skewness(log(y+lam))','lam','y');
    lam=fzero(f,[-min(y1)+eps abs(100*(1+min(y1)))],[],y1);
    yl = log(y1+lam);
    gsa_log(j) = gsa_sdp_dyn(yl, x, pshape, pd, gsa_flag, [MhDirectoryName,'/',fname,'_log',int2str(j)], M_.param_names);
    id = find(gsa_log(j).multivariate.stat>1.65);
    f1(:,j) = isig*(-lam+exp(mean(yl)+sum(gsa_log(j).multivariate.f(:,id), 2)));
%     e = (y1+lam)./exp(mean(yl)+sum(gsa_log(j).multivariate.f(:,id), 2));
%     gsa_e(j) = gsa_sdp_dyn(e, x, pshape, pd, gsa_flag, [MhDirectoryName,'/',fname,'_res',int2str(j)], M_.param_names);    
    g1 = mean(yl)+sum(gsa_log(j).multivariate.f(:,id), 2);
    S_log(j,:)=gsa_log(j).multivariate.si;

  else
    if kurtosis(y0)>20,
      yl = log((y0-mean(y0)).^2);
      gsa_log(j) = gsa_sdp_dyn(yl, x, pshape, pd, gsa_flag, [MhDirectoryName,'/',fname,'_log',int2str(j)], M_.param_names);      
      id = find(gsa_log(j).multivariate.stat>1.65);
      f1(:,j) = sqrt(exp(mean(yl)+sum(gsa_log(j).multivariate.f(:,id), 2))).*sign(y0-mean(y0))+mean(y0);
%     e = (y1+lam)./exp(mean(yl)+sum(gsa_log(j).multivariate.f(:,id), 2));
%     gsa_e(j) = gsa_sdp_dyn(e, x, bayestopt_.pshape, [bayestopt_.p1 bayestopt_.p2 bayestopt_.p3 bayestopt_.p4], gsa_flag, [MhDirectoryName,'/',fname,'_res',int2str(j)], M_.param_names);    
      g1 = mean(yl)+sum(gsa_log(j).multivariate.f(:,id), 2);
      S_log(j,:)=gsa_log(j).multivariate.si;
    else
      gsa_(j) = gsa_sdp_dyn(y0, x, pshape, pd, gsa_flag, [MhDirectoryName,'/',fname,int2str(j)], M_.param_names);
      id = find(gsa_(j).multivariate.stat>1.65);
      f1(:,j) = mean(y0) + sum(gsa_(j).multivariate.f(:,id), 2);
      S(j,:)=gsa_(j).multivariate.si;
      e = (y0-f1(:,j));
      yl = log((y0-f1(:,j)).^2); 
      gsa_log(j) = gsa_sdp_dyn(yl, x, pshape, pd, gsa_flag, [MhDirectoryName,'/',fname,'_log',int2str(j)], M_.param_names);      
      id = find(gsa_log(j).multivariate.stat>1.65);
      g1 = (exp(mean(yl)+sum(gsa_log(j).multivariate.f(:,id), 2)));
      f0 = sum(gsa_log(j).multivariate.f(:,id), 2);
    end

  end
end

if ~exist('gsa_log'), gsa_log=[]; end
if ~exist('gsa_'), gsa_=[]; end